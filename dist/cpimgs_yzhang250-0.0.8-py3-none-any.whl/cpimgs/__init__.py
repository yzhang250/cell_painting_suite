name = "cpimgs"
__version__ = '0.0.8'